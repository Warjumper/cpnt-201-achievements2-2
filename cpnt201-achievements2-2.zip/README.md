# Tutorial Framework Session
## cpnt201-achievements2-2

### By Jesse H

## Process notes/Code journal;
- The first thing I did was watch https://www.youtube.com/watch?v=cuHDQhDhvPE&ab_channel=Fireship to decide which framework to build with.
- I chose Vue after reading the reviews and listening to the video, mostly becasue of ease of use.
- Many of the videos were quite long, but I found this one https://www.youtube.com/watch?v=bzlFvd0b65c&t=164s&ab_channel=VueMastery. Clocking in at just under an hour, its comments made it sound like it was very well done.
- Sadly, my codepen account said it required a paid version to fork the lesseon from the video, so I opted to do it the long way, and write it out myself. I could use the practice.
- Learning es6: shorthand!? (Why have I done this to myself?)
- I love that he stops to explain WHY the things im doing are working. This is what I need!
- MUSTACHE SYNTAX.
- I have started to regret doing the coding challenges, as they are taking up my time (which I am running short on!) and they are often replaced by future coding as I progress.
- It is amazing seeing everything start to come together!
- Setting CSS in JS is interesting, and learning more about the difference between camelCase and kebob-case (and how quotes were required) was helpful.
- In the interest of saving time, I have copied some of the remaining CSS code for the finished app.
- By the time I hit part 9, I was lost in the sauce, confused and in too deep. The nice part ow is that things started to become more organized as it went further ahead.
- Having an error come up asking me to fill out the entire form is a great feature and cool to see implemented.
- Two way data binding confuses me. This will require further google-fu.

Overall, I was lost as to why the magic worked by the time I finished. I think delveing further into Vue or working through similar tutorials in the future would help me. I really liked the addition of being able to view some of the codepen, even if I couldn't touch it, to help with some of my syntax errors.

I would highly reccomend this channel to anyone who is wanting to learn Vue, as the guide does an excellent job of explaining things at an easier to follow pace than most other tutorials I have done.

### Channel Link: https://www.youtube.com/c/VueMastery